import asyncio, os, subprocess, textwrap
from PIL import Image, ImageDraw, ImageFont
import edge_tts

W,H=1080,1920
OUT="output"
os.makedirs(OUT,exist_ok=True)
with open("script.txt",encoding="utf-8") as f: script=f.read().strip()

async def voice():
    tts=edge_tts.Communicate(script, voice="es-ES-AlvaroNeural", rate="-5%")
    await tts.save(f"{OUT}/voice.mp3")
asyncio.run(voice())

# Simple background + readable text card
im=Image.new("RGB",(W,H),(12,22,45))
d=ImageDraw.Draw(im)
for y in range(H):
    c=int(20+35*y/H)
    d.line((0,y,W,y),fill=(8,c,55))
try: font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",64)
except: font=ImageFont.load_default()
lines=textwrap.wrap(script, width=25)
text="\n".join(lines)
bbox=d.multiline_textbbox((0,0),text,font=font,spacing=22,align="center")
tw=bbox[2]-bbox[0]; th=bbox[3]-bbox[1]
x=(W-tw)//2; y=(H-th)//2
d.rounded_rectangle((x-55,y-55,x+tw+55,y+th+55),radius=35,fill=(0,0,0,180),outline=(255,255,255),width=3)
d.multiline_text((x,y),text,font=font,fill="white",spacing=22,align="center",stroke_width=1,stroke_fill="black")
im.save(f"{OUT}/background.png")
subprocess.run(["ffmpeg","-y","-loop","1","-i",f"{OUT}/background.png","-i",f"{OUT}/voice.mp3","-c:v","libx264","-tune","stillimage","-c:a","aac","-b:a","192k","-pix_fmt","yuv420p","-shortest","-vf","scale=1080:1920","-r","30",f"{OUT}/short.mp4"],check=True)
print("Creado:",f"{OUT}/short.mp4")

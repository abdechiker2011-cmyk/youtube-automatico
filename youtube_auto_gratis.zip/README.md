# YouTube Shorts automático (base gratuita)

Esta plantilla genera un Short vertical con voz TTS y subtítulos usando Python/FFmpeg.
No sube automáticamente a YouTube ni se despliega sola: eso requiere configurar credenciales OAuth y un runner/servicio en la nube.

## Requisitos
- Python 3.10+
- FFmpeg instalado
- `pip install -r requirements.txt`

## Uso
1. Edita `script.txt` con un texto original breve (20–45 segundos).
2. Ejecuta `python make_short.py`.
3. El resultado estará en `output/short.mp4`.

## Automatización en la nube
GitHub Actions puede ejecutar el script en horarios programados, pero sus minutos gratuitos son limitados y los horarios pueden retrasarse.
Para publicar en YouTube, configura OAuth de YouTube Data API y añade un paso de subida. No compartas contraseñas ni tokens en el código.
